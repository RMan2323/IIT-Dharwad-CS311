// package generic;

// public class ArithmeticEvent extends Event {
//     public int rd, op1, op2;
//     public enum OperationType {mul, div, other};
//     public OperationType operation;
	
// 	public ArithmeticEvent(long eventTime, int op1, int op2, Element requestingElement, Element processingElement, int rd, OperationType operation) {
// 		super(eventTime, EventType.ArithmeticEvent, requestingElement, processingElement);
// 		this.op1 = op1;
//         this.op2 = op2;
//         this.rd = rd;
//         this.operation = operation;
// 	}
// }
